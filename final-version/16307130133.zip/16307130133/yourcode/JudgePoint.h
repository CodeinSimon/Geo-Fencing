//
// Created by Simon Nie on 2018/12/12.
//

#ifndef INC_16307130133_JUDGEPOINT_H
#define INC_16307130133_JUDGEPOINT_H

#include<vector>

extern std::vector<float> constant;
extern std::vector<float> multiple;

void freeRoom();

void precalc_values(int polyCorners, std::vector<std::pair<double, double> > &polygon);

bool pointInPolygon(int polyCorners, std::vector<std::pair<double, double> > &polygon, float x, float y);

#endif //INC_16307130133_JUDGEPOINT_H

