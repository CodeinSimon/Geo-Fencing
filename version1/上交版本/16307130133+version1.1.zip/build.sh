#! /bin/bash
cmake . && make