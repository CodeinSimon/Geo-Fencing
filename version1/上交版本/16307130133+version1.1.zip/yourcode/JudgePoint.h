//
// Created by Simon Nie on 2018/12/12.
//

#ifndef INC_16307130133_JUDGEPOINT_H
#define INC_16307130133_JUDGEPOINT_H

#include<vector>

bool pointInPolygon(double px, double py, std::vector<std::pair<double, double>> &polygon);
#endif //INC_16307130133_JUDGEPOINT_H

