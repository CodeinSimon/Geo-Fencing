//
// Created by Simon Nie on 2019/1/6.
// @Copyright (c) 2019 Simon Nie. All rights reserved.
//

#ifndef INC_16307130133_3_GLOBAL_H
#define INC_16307130133_3_GLOBAL_H

#include <vector>
#include <unordered_map>
#include <stdio.h>
#include "RTree.h"
#include "GridPoint.h"
const int MX = INT_MAX;
const int MIN = INT_MIN;

struct Rect
{
    Rect() {}
    // constructor
    Rect(double& a_minX, double& a_minY, double& a_maxX, double& a_maxY)
    {
        min[0] = a_minX;
        min[1] = a_minY;

        max[0] = a_maxX;
        max[1] = a_maxY;
    }
    // copy constructor
    Rect(const Rect& a){
        min[0] = a.min[0];
        min[1] = a.min[1];
        max[0] = a.max[0];
        max[1] = a.max[1];
    }
    ~Rect() = default;
    double min[2];
    double max[2];
};

extern std::unordered_map<int, std::vector<std::pair<double, double> > > polygon_set;
extern std::unordered_map<int, std::pair<double, double> > point_set;
//extern std::vector<std::pair<int,int> > polygon_ids;
extern std::vector<int> point_ids;
extern std::vector<int> hit_polygon_ids;
extern std::vector<int> hit_point_ids;
typedef RTree<int, double, 2, double> MyTree;
extern MyTree polygonTree;
extern std::unordered_map<int, Rect> polygon_rect;
extern std::unordered_map<int, bool> point_is_deleted;
extern std::unordered_map<int, bool> polygon_is_deleted;
//extern std::unordered_map<int, GridSet*> polygon_grid;

#endif //INC_16307130133_3_GLOBAL_H
