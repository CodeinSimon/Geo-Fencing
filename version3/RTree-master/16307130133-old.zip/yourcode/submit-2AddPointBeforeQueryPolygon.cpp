#include "submit-2AddPointBeforeQueryPolygon.h"

void SetEnvironmentFromAddPointBeforeQueryPolygon() {
}

void AddPointFromAddPointBeforeQueryPolygon(int id, double x, double y) {
    point_set[id] = std::make_pair(x, y);
    point_ids.push_back(id);
    point_is_deleted[id] = false;
}

std::vector<int> QueryPolygonFromAddPointBeforeQueryPolygon(int n, std::vector<std::pair<double, double> > polygon) {
    std::vector<int> hit_point_ids;
    GridSet p_gs;
    double tmpPoly[n][2];
    for (int i = 0;i< n;i++){
        tmpPoly[i][0] = polygon[i].first;
        tmpPoly[i][1] = polygon[i].second;
    }
    GridSetup(tmpPoly, n, 100, &p_gs);
    for(auto e: point_ids){
        if(point_is_deleted[e]) continue;
        double point[2] = {point_set[e].first, point_set[e].second};
        if(GridTest(&p_gs, point))
            hit_point_ids.push_back(e);
    }
    GridCleanup(&p_gs);
    return hit_point_ids;
}
