#include "submit-3AddBeforeQuery.h"

void SetEnvironmentFromAddBeforeQuery(){
}

inline bool SearchCallback3(int id) {
    hit_polygon_ids.push_back(id);
    return true;
}

void AddPointFromAddBeforeQuery(int id, double x, double y) {
    point_set[id] = std::make_pair(x, y);
    point_ids.push_back(id);
    point_is_deleted[id] = false;

}

void AddPolygonFromAddBeforeQuery(int id, int n, std::vector<std::pair<double, double> > &polygon) {
    double a_minX = MX, a_minY = MX, a_maxX = MIN, a_maxY = MIN, tmpx, tmpy;
    for (int i = 0; i < n; i++) {
        tmpx = polygon[i].first;
        tmpy = polygon[i].second;
        a_minX = std::min(a_minX, tmpx);
        a_minY = std::min(a_minY, tmpy);
        a_maxX = std::max(a_maxX, tmpx);
        a_maxY = std::max(a_maxY, tmpy);
    }
    Rect tmpRect(a_minX, a_minY, a_maxX, a_maxY);
    polygonTree.Insert(tmpRect.min, tmpRect.max, id);
    polygon_set[id] = polygon;
    return;
}

std::vector<int> QueryPointFromAddBeforeQuery(double x, double y) {
    hit_polygon_ids.clear();
    std::vector<int> polygon_ids;
    Rect pointRect(x, y, x, y);
    int nHits;
    nHits = polygonTree.Search(pointRect.min, pointRect.max, SearchCallback3);
    for (int i = 0; i < nHits; i++) {
        int tmpId = hit_polygon_ids[i];
        std::vector<std::pair<double, double> >& a_polygon = polygon_set[tmpId];
        if(pointInPolygon(x, y, a_polygon))
            polygon_ids.push_back(tmpId);
    }
    return polygon_ids;
}


std::vector<int> QueryPolygonFromAddBeforeQuery(int n, std::vector<std::pair<double, double> > &polygon) {
    std::vector<int> hit_point_ids;
    GridSet p_gs;
    double tmpPoly[n][2];
    for (int i = 0;i< n;i++){
        tmpPoly[i][0] = polygon[i].first;
        tmpPoly[i][1] = polygon[i].second;
    }
    GridSetup(tmpPoly, n, 20, &p_gs);
    for(auto e: point_ids){
        if(point_is_deleted[e]) continue;
        double point[2] = {point_set[e].first, point_set[e].second};
        if(GridTest(&p_gs, point))
            hit_point_ids.push_back(e);
    }
    GridCleanup(&p_gs);
    return hit_point_ids;
}